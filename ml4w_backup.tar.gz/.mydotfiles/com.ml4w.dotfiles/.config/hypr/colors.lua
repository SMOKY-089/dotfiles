
background = "rgba(1a110eff)"

error = "rgba(ffb4abff)"

error_container = "rgba(93000aff)"

inverse_on_surface = "rgba(382e2aff)"

inverse_primary = "rgba(8e4d2fff)"

inverse_surface = "rgba(f1dfd9ff)"

on_background = "rgba(f1dfd9ff)"

on_error = "rgba(690005ff)"

on_error_container = "rgba(ffdad6ff)"

on_primary = "rgba(542106ff)"

on_primary_container = "rgba(ffdbcdff)"

on_primary_fixed = "rgba(360f00ff)"

on_primary_fixed_variant = "rgba(71361aff)"

on_secondary = "rgba(442a1fff)"

on_secondary_container = "rgba(ffdbcdff)"

on_secondary_fixed = "rgba(2c160cff)"

on_secondary_fixed_variant = "rgba(5d4034ff)"

on_surface = "rgba(f1dfd9ff)"

on_surface_variant = "rgba(d8c2baff)"

on_tertiary = "rgba(373106ff)"

on_tertiary_container = "rgba(efe3a9ff)"

on_tertiary_fixed = "rgba(201c00ff)"

on_tertiary_fixed_variant = "rgba(4e471bff)"

outline = "rgba(a08d85ff)"

outline_variant = "rgba(53443eff)"

primary = "rgba(ffb596ff)"

primary_container = "rgba(71361aff)"

primary_fixed = "rgba(ffdbcdff)"

primary_fixed_dim = "rgba(ffb596ff)"

scrim = "rgba(000000ff)"

secondary = "rgba(e6beaeff)"

secondary_container = "rgba(5d4034ff)"

secondary_fixed = "rgba(ffdbcdff)"

secondary_fixed_dim = "rgba(e6beaeff)"

shadow = "rgba(000000ff)"

source_color = "rgba(ca4f02ff)"

surface = "rgba(1a110eff)"

surface_bright = "rgba(423733ff)"

surface_container = "rgba(271e1aff)"

surface_container_high = "rgba(322824ff)"

surface_container_highest = "rgba(3d322eff)"

surface_container_low = "rgba(231a16ff)"

surface_container_lowest = "rgba(140c09ff)"

surface_dim = "rgba(1a110eff)"

surface_tint = "rgba(ffb596ff)"

surface_variant = "rgba(53443eff)"

tertiary = "rgba(d2c78fff)"

tertiary_container = "rgba(4e471bff)"

tertiary_fixed = "rgba(efe3a9ff)"

tertiary_fixed_dim = "rgba(d2c78fff)"


