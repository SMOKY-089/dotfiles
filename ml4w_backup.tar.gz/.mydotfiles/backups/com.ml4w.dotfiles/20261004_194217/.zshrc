source /usr/share/cachyos-zsh-config/cachyos-config.zsh


# Added by Antigravity CLI installer
export PATH="/home/katana/.local/bin:$PATH"

# Added by LM Studio CLI (lms)
export PATH="$PATH:/home/katana/.lmstudio/bin"
# End of LM Studio CLI section

