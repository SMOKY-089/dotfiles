hl.bind("CTRL+SUPER+ALT+Slash", hl.dsp.exec_cmd("xdg-open ~/.config/hypr/custom/keybinds.lua"), {description = "Edit user keybinds"} )

-- ─────────────────────────────────────────────
-- Vim-style Workspace Navigation
-- ─────────────────────────────────────────────
hl.bind("CTRL + SUPER + H", hl.dsp.focus({ workspace = "r-1" }), { description = "Workspace: Focus left (Vim)" })
hl.bind("CTRL + SUPER + L", hl.dsp.focus({ workspace = "r+1" }), { description = "Workspace: Focus right (Vim)" })

hl.bind("CTRL + SUPER + SHIFT + H", hl.dsp.window.move({ workspace = "r-1" }), { description = "Window: Move to workspace left (Vim)" })
hl.bind("CTRL + SUPER + SHIFT + L", hl.dsp.window.move({ workspace = "r+1" }), { description = "Window: Move to workspace right (Vim)" })
