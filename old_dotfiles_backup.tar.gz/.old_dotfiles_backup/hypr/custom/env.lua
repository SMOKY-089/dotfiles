local home_dir = os.getenv("HOME")
local path_old = os.getenv("PATH") or ""

-- Add ~/.local/bin to PATH for Hyprland environment
hl.env("PATH", home_dir .. "/.local/bin:" .. path_old)
