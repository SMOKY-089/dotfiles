-- Modern, Fluid Hyprland Animation Suite (Reddit & Material 3 Inspired)

-- Bezier Curves & Springs
hl.curve("md3_decel",   { type = "bezier", points = { {0.05, 0.7},  {0.1, 1.0}   } })
hl.curve("md3_accel",   { type = "bezier", points = { {0.3, 0},     {0.8, 0.15}  } })
hl.curve("overshoot",   { type = "bezier", points = { {0.05, 0.9},  {0.1, 1.05}  } })
hl.curve("hyprsnappy",  { type = "bezier", points = { {0.1, 1.0},   {0, 1.0}     } })
hl.curve("smoothOut",   { type = "bezier", points = { {0.36, 0},    {0.66, -0.56}} })
hl.curve("gnomeEase",   { type = "bezier", points = { {0.25, 1},    {0.5, 1}     } })

hl.curve("bouncy",      { type = "spring", mass = 1, stiffness = 300, dampening = 20 })
hl.curve("smoothSpring",{ type = "spring", mass = 1, stiffness = 180, dampening = 24 })

-- Global Toggle
hl.animation({ leaf = "global",              enabled = true, speed = 3, bezier = "md3_decel" })

-- Windows (Opening, Closing, Moving & Resizing)
hl.animation({ leaf = "windows",             enabled = true, speed = 3, bezier = "md3_decel", style = "popin 80%" })
hl.animation({ leaf = "windowsIn",           enabled = true, speed = 3, bezier = "overshoot", style = "popin 85%" })
hl.animation({ leaf = "windowsOut",          enabled = true, speed = 2, bezier = "md3_accel", style = "popin 80%" })
hl.animation({ leaf = "windowsMove",         enabled = true, speed = 4, bezier = "md3_decel" })

-- Fade & Transparency Effects
hl.animation({ leaf = "fade",                enabled = true, speed = 3, bezier = "md3_decel" })
hl.animation({ leaf = "fadeIn",              enabled = true, speed = 3, bezier = "md3_decel" })
hl.animation({ leaf = "fadeOut",             enabled = true, speed = 2, bezier = "md3_accel" })
hl.animation({ leaf = "fadeSwitch",          enabled = true, speed = 3, bezier = "md3_decel" })
hl.animation({ leaf = "fadeShadow",          enabled = true, speed = 3, bezier = "md3_decel" })
hl.animation({ leaf = "fadeDim",             enabled = true, speed = 3, bezier = "md3_decel" })
hl.animation({ leaf = "border",              enabled = true, speed = 4, bezier = "md3_decel" })

-- Workspaces (Slide & Fade 20%)
hl.animation({ leaf = "workspaces",          enabled = true, speed = 4, bezier = "md3_decel", style = "slidefade 20%" })
hl.animation({ leaf = "specialWorkspaceIn",  enabled = true, speed = 3, bezier = "overshoot", style = "slide top" })
hl.animation({ leaf = "specialWorkspaceOut", enabled = true, speed = 3, bezier = "md3_accel", style = "slide bottom" })

-- UI Layers (Noctalia Panels, Launcher, Waybar, Notifications)
hl.animation({ leaf = "layers",              enabled = true, speed = 3, bezier = "md3_decel", style = "popin 80%" })
hl.animation({ leaf = "layersIn",            enabled = true, speed = 3, bezier = "overshoot", style = "popin 80%" })
hl.animation({ leaf = "layersOut",           enabled = true, speed = 2, bezier = "md3_accel", style = "fade" })
hl.animation({ leaf = "fadeLayers",          enabled = true, speed = 3, bezier = "md3_decel" })
