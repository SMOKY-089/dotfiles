-- Workspace rules wiki https://wiki.hypr.land/Configuring/Basics/Workspace-Rules/
-- Add your workspace rules here. Increment the workspace number as you go. Do not have duplicate workspaces.
hl.workspace_rule({ workspace = "name:gaming", monitor = PRIMARY_MONITOR, default = true })
hl.workspace_rule({ workspace = "1",  monitor = MONITOR1, default = true, persistent = true })
hl.workspace_rule({ workspace = "2",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "3",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "4",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "5",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "6",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "7",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "8",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "9",  monitor = MONITOR1, persistent = true })
hl.workspace_rule({ workspace = "10", monitor = MONITOR1, persistent = true })

-- Auto-launch Super Productivity into the notes scratchpad when Super + N is pressed
hl.workspace_rule({ workspace = "special:notes", on_created_empty = "flatpak run com.super_productivity.SuperProductivity" })